fx_version 'cerulean'
game 'gta5'
author 'HXVRMXN.dev & IcePick'
description 'IcePicks Animation Overhaul Mod made to work Server Sided by HXVRMXN.dev'
version '1.0.0'

files {
	'weaponanimations.meta',
	'**/weaponanimations.meta'
}

data_file 'WEAPON_ANIMATIONS_FILE' '**/weaponanimations.meta'
data_file 'WEAPON_ANIMATIONS_FILE' 'weaponanimations.meta '
